
from sklearn.linear_model import LinearRegression
import numpy as np
 

x= np.array([[1],[5],[10],[20],[30]])
y= np.array([7000,10000,13000,18000,45000])


model= LinearRegression()
model.fit(x,y)

predicted_price = model.predict([[15]])
print(predicted_price)


