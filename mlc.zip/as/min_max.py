from sklearn.preprocessing import MinMaxScaler
import pandas as pd
import numpy as np

# 1️⃣ تولید داده‌ی فرضی
data = {
    'customer_id': range(1, 101),
    'total_spent': np.random.randint(100, 5000, 100),
    'num_purchases': np.random.randint(1, 50, 100),
    'categories_bought': np.random.randint(1, 10, 100),
    'avg_purchase_value': np.random.randint(10, 500, 100)
}
df = pd.DataFrame(data)
df.set_index('customer_id', inplace=True)  # حذف شناسه از پردازش

# 2️⃣ اعمال Min-Max Scaling
scaler = MinMaxScaler(feature_range=(0, 1))  # بازه 0 تا 1
df_scaled = pd.DataFrame(scaler.fit_transform(df), columns=df.columns, index=df.index)

# 3️⃣ نمایش نمونه‌ای از داده‌های نرمال‌شده
print(df_scaled.head())
