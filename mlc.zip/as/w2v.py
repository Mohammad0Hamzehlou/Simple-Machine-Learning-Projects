import gensim
from gensim.models import Word2Vec
from nltk.tokenize import word_tokenize

# 1️⃣ نمونه داده‌های متنی
texts = [
    "من عاشق یادگیری ماشین هستم",
    "پردازش زبان طبیعی فوق‌العاده است",
    "یادگیری ماشین و هوش مصنوعی در حال تغییر دنیا هستند"
]

# 2️⃣ توکنایز کردن (جداسازی کلمات)
tokenized_texts = [word_tokenize(text.lower()) for text in texts]

# 3️⃣ ساخت مدل Word2Vec
model_w2v = Word2Vec(sentences=tokenized_texts, vector_size=100, window=5, min_count=1, workers=4)

# 4️⃣ نمایش بردار عددی کلمه "یادگیری"
print("\n🔹 بردار کلمه 'یادگیری':\n", model_w2v.wv["یادگیری"])
