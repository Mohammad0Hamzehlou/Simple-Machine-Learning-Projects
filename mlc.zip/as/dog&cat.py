import tensorflow as tf
import os
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from tensorflow.keras import layers, models

import matplotlib.pyplot as plt
import numpy as np
import cv2
# دانلود مجموعه داده
dataset_url = "https://storage.googleapis.com/mledu-datasets/cats_and_dogs_filtered.zip"
path_to_zip = tf.keras.utils.get_file("cats_and_dogs.zip", origin=dataset_url, extract=True)

# مسیر مجموعه داده
dataset_path = os.path.join(os.path.dirname(path_to_zip), "cats_and_dogs_filtered")
train_dir = os.path.join(dataset_path, "train")
validation_dir = os.path.join(dataset_path, "validation")

img_size = (150, 150)
batch_size = 32

# ایجاد آبجکت برای بارگذاری داده‌ها
train_datagen = ImageDataGenerator(rescale=1.0/255.0)
val_datagen = ImageDataGenerator(rescale=1.0/255.0)

train_generator = train_datagen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch_size, class_mode="binary")

validation_generator = val_datagen.flow_from_directory(
    validation_dir, target_size=img_size, batch_size=batch_size, class_mode="binary")



model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation="relu", input_shape=(150, 150, 3)),
    layers.MaxPooling2D(2, 2),
    
    layers.Conv2D(64, (3, 3), activation="relu"),
    layers.MaxPooling2D(2, 2),

    layers.Conv2D(128, (3, 3), activation="relu"),
    layers.MaxPooling2D(2, 2),

    layers.Flatten(),
    layers.Dense(512, activation="relu"),
    layers.Dense(1, activation="sigmoid")  # خروجی باینری (گربه یا سگ)
])

# کامپایل مدل
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

epochs = 10  # تعداد تکرارها

history = model.fit(
    train_generator,
    epochs=epochs,
    validation_data=validation_generator
)




# رسم نمودار دقت و خطا
acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs_range = range(epochs)

plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(epochs_range, acc, label="دقت آموزش")
plt.plot(epochs_range, val_acc, label="دقت اعتبارسنجی")
plt.legend(loc="lower right")
plt.title("دقت مدل")

plt.subplot(1, 2, 2)
plt.plot(epochs_range, loss, label="خطای آموزش")
plt.plot(epochs_range, val_loss, label="خطای اعتبارسنجی")
plt.legend(loc="upper right")
plt.title("خطای مدل")
plt.show()



def predict_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (150, 150)) / 255.0
    img = np.expand_dims(img, axis=0)  # افزودن بعد دسته‌ای
    
    prediction = model.predict(img)[0][0]
    
    if prediction > 0.5:
        print("🐶 این تصویر یک سگ است!")
    else:
        print("🐱 این تصویر یک گربه است!")

# تست یک تصویر
predict_image("test_image.jpg")



