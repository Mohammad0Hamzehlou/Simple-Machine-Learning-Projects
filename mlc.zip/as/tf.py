from sklearn.feature_extraction.text import TfidfVectorizer

# داده‌های متنی (مثال: دو جمله ساده)
documents = [
    "گربه روی دیوار نشست.",
    "سگ و گربه در حیاط بازی کردند."
]

# ایجاد مدل TF-IDF
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(documents)

# نمایش کلمات و مقدار TF-IDF آنها
feature_names = vectorizer.get_feature_names_out()
print("ویژگی‌ها (کلمات):", feature_names)
print("ماتریس TF-IDF:\n", tfidf_matrix.toarray())
