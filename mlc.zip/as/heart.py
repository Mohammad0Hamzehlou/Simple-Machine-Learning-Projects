import numpy as np
import pandas as pd
from ucimlrepo import fetch_ucirepo
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# 🚀 1. دریافت دیتاست
heart_disease = fetch_ucirepo(id=45)

# تبدیل داده‌ها به DataFrame
X = heart_disease.data.features
y = heart_disease.data.targets

# 🚀 2. بررسی و اصلاح مقادیر گمشده
imputer = SimpleImputer(strategy="mean")
X_imputed = imputer.fit_transform(X)

# 🚀 3. نرمال‌سازی داده‌ها
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)

# 🚀 4. تقسیم داده‌ها به آموزش و تست
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 🚀 5. مدل‌سازی
model = LogisticRegression()
model.fit(X_train, y_train)

# 🚀 6. گرفتن ورودی از کاربر و پیش‌بینی
def predict_heart_disease():
    print("\n🔴 لطفاً اطلاعات زیر را وارد کنید:")
    
    age = float(input("📌 سن: "))
    sex = int(input("📌 جنسیت (1 = مرد، 0 = زن): "))
    cp = int(input("📌 نوع درد قفسه سینه (0 تا 3): "))
    trestbps = float(input("📌 فشار خون استراحت (مثال: 130): "))
    chol = float(input("📌 کلسترول (مثال: 250): "))
    fbs = int(input("📌 قند خون ناشتا > 120؟ (1 = بله، 0 = خیر): "))
    restecg = int(input("📌 نتایج الکتروکاردیوگرافی (0 تا 2): "))
    thalach = float(input("📌 حداکثر ضربان قلب: "))
    exang = int(input("📌 آنژین ناشی از ورزش؟ (1 = بله، 0 = خیر): "))
    oldpeak = float(input("📌 میزان افت ST: "))
    slope = int(input("📌 شیب قطعه ST (0 تا 2): "))
    ca = int(input("📌 تعداد رگ‌های اصلی رنگ‌شده (0 تا 4): "))
    thal = int(input("📌 مقدار thal (1, 2, 3): "))

    # ساخت آرایه ورودی
    user_input = np.array([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])

    # نرمال‌سازی ورودی کاربر با استفاده از **همان Scaler**
    user_input_scaled = scaler.transform(user_input)

    # پیش‌بینی بیماری قلبی
    prediction = model.predict(user_input_scaled)[0]

    # نمایش نتیجه
    if prediction == 1:
        print("\n🚨 هشدار: احتمال بیماری قلبی وجود دارد! لطفاً به پزشک مراجعه کنید.")
    else:
        print("\n✅ شما در وضعیت طبیعی هستید. نگران نباشید!")

# اجرای تابع برای پیش‌بینی
predict_heart_disease()
