import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

# 1️⃣ داده‌های متنی نمونه
texts = [
    "من عاشق یادگیری ماشین هستم!",
    "پردازش زبان طبیعی فوق‌العاده است.",
    "یادگیری ماشین و هوش مصنوعی در حال تحول دنیا هستند."
]

# 2️⃣ اعمال مدل TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)

# 3️⃣ تبدیل به DataFrame برای مشاهده بهتر
df = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())

print("\n🔹 ویژگی‌های استخراج‌شده از متن:\n")
print(df)


