import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# 1️⃣ داده‌سازی (دیتاست فرضی)
data = {
    'customer_id': range(1, 101),
    'total_spent': np.random.randint(100, 5000, 100),
    'num_purchases': np.random.randint(1, 50, 100),
    'categories_bought': np.random.randint(1, 10, 100),
    'avg_purchase_value': np.random.randint(10, 500, 100)
}
df = pd.DataFrame(data)
df.set_index('customer_id', inplace=True)

# 2️⃣ نرمال‌سازی داده‌ها
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df)

# 3️⃣ اعمال KMeans
kmeans = KMeans(n_clusters=3, n_init="auto", random_state=42)
df["cluster"] = kmeans.fit_predict(X_scaled)

# 4️⃣ نمایش تعداد مشتریان در هر خوشه
print("\n🔹 تعداد مشتریان در هر خوشه:\n", df['cluster'].value_counts())

# 5️⃣ بررسی ویژگی‌های هر خوشه
cluster_summary = df.groupby("cluster").mean()
print("\n📊 میانگین ویژگی‌های هر خوشه:\n", cluster_summary)
