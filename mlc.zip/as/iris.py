from ucimlrepo import fetch_ucirepo
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd

# 🚀 دریافت دیتاست
iris = fetch_ucirepo(id=53)

# تبدیل داده‌ها به DataFrame
X = iris.data.features
y = iris.data.targets

# 🚀 استانداردسازی داده‌ها (بسیار مهم برای KMeans)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 🚀 اعمال KMeans با 3 خوشه
kmeans = KMeans(n_clusters=3, n_init=10, random_state=42)
kmeans.fit(X_scaled)

# 🚀 نمایش برچسب‌های خوشه‌بندی‌شده
print("🔹 برچسب‌های خوشه‌بندی:", kmeans.labels_)

# 🚀 بررسی مقایسه‌ای بین خوشه‌بندی و دسته‌های واقعی
df = pd.DataFrame({"واقعی": y.values.flatten(), "پیش‌بینی‌شده": kmeans.labels_})
print("\n🔹 مقایسه دسته‌های واقعی و پیش‌بینی‌شده:\n", df.value_counts())

