from textblob import TextBlob

text = "I love you and and this love is a romantic love!"
sentiment = TextBlob(text).sentiment.polarity
print(sentiment)  # خروجی مثبت (نزدیک به ۱)
