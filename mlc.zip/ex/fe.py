import pandas as pd



data = {'Experience': [1, 3, 5, 7, 9], 'Salary': [30, 50, 70, 90, 110]}
df = pd.DataFrame(data)

df['Experience_Squared'] = df['Experience'] ** 2

print(df)


