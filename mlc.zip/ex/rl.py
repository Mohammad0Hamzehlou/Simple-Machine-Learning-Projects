import gym
import numpy as np

env = gym.make("FrozenLake-v1")
state = env.reset()
print("محیط آماده شد!")
