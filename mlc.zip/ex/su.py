from sklearn.linear_model import LinearRegression
import numpy as np
 

x= np.array([[50],[60],[70],[80],[90]])
y= np.array([500,600,800,900,1000])


model= LinearRegression()
model.fit(x,y)

predicted_price = model.predict([[100]])
print(predicted_price)