from sklearn.cluster import KMeans
import numpy as np

x = np.array([[25,3000],[30,35000],[35,60000],[40,70000]])

kmeans = KMeans(n_clusters=2)
kmeans.fit(x)

print(kmeans.labels_)